
    getUrl("EVRpoolPAY").then(
        function (data) {
        	let currenttime = Date.now();
			let countdown = data.payments.next - currenttime;
			setInterval(()=>{
				if (countdown > 0) {
					countdown -= 1000;
				document.getElementById("nextpayment").innerHTML = timetotime(countdown);
				} else {
                    countdown = 720 * 60000;
					//countdown = 30 * 60000;
				}
			}, 1000);
        },
        function (error) { /* code if some error */ }
    );
    let urlToParse = new URL(window.location.href);
	let split = urlToParse.searchParams.get("").split(".");
    let urlParsedAddress = split[0];
	let urlParsedZilAddress = split[1];

    let walletimg = '<img src="./img/EVR_LOGO_BLUE.svg" style="height: 56px; width: 56px">'
	let walletimg2 = '<svg clip-rule="evenodd" style="height: 56px; width: 56px" fill-rule="evenodd" stroke-linejoin="round" stroke-miterlimit="2" viewBox="0 0 560 400" xmlns="http://www.w3.org/2000/svg"><g fill-rule="nonzero"><path d="m672.926 1657.83-359.964 160.49-954.935 486.06 954.935 459.13v-758.9l359.964-162.22v1121.16l-359.964 160.5-1406.032-672.93v-357.67l973.273-477.47-973.273-467.72v-362.831l365.691-160.493 1400.305 674.074z" fill="#49c1bf" transform="matrix(.11325 0 0 .11325 303.790648 -12.303809)"/><path d="m-1093.07 785.429 1406.032 674.071 359.964-160.49-1400.305-674.074z" fill="#077a8f" transform="matrix(.11325 0 0 .11325 303.790648 -12.303809)"/><path d="m209.788 1408.49 359.963-160.5v358.82l-359.963 160.49z" fill="#298e97" transform="matrix(.11325 0 0 .11325 315.476915 -6.6985)"/><path d="m-1093.07 773.965v362.835l973.273 467.72-973.273 477.47v357.67l1406.032 672.92v-359.96l-954.935-459.7 954.935-486.06v-358.82z" fill="#49c1bf" transform="matrix(.11325 0 0 .11325 303.790648 -10.969157)"/><path d="m209.788 3032.34 359.963-160.5v-1121.16l-359.963 162.21z" fill="#298e97" transform="matrix(.11325 0 0 .11325 315.476915 -2.184355)"/></g></svg>';
    //document.getElementById("mineraddress").innerHTML = '<h4 class="card-title">' + walletimg + ' ' + urlParsedAddress + '</h4>';
    let evrimg = '<img src="./img/EVR_LOGO_BLUE.svg" style="height: 32px; width: 32px">'
	let zilimg = '<svg clip-rule="evenodd" style="height: 32px; width: 32" fill-rule="evenodd" stroke-linejoin="round" stroke-miterlimit="2" viewBox="0 0 560 400" xmlns="http://www.w3.org/2000/svg"><g fill-rule="nonzero"><path d="m672.926 1657.83-359.964 160.49-954.935 486.06 954.935 459.13v-758.9l359.964-162.22v1121.16l-359.964 160.5-1406.032-672.93v-357.67l973.273-477.47-973.273-467.72v-362.831l365.691-160.493 1400.305 674.074z" fill="#49c1bf" transform="matrix(.11325 0 0 .11325 303.790648 -12.303809)"/><path d="m-1093.07 785.429 1406.032 674.071 359.964-160.49-1400.305-674.074z" fill="#077a8f" transform="matrix(.11325 0 0 .11325 303.790648 -12.303809)"/><path d="m209.788 1408.49 359.963-160.5v358.82l-359.963 160.49z" fill="#298e97" transform="matrix(.11325 0 0 .11325 315.476915 -6.6985)"/><path d="m-1093.07 773.965v362.835l973.273 467.72-973.273 477.47v357.67l1406.032 672.92v-359.96l-954.935-459.7 954.935-486.06v-358.82z" fill="#49c1bf" transform="matrix(.11325 0 0 .11325 303.790648 -10.969157)"/><path d="m209.788 3032.34 359.963-160.5v-1121.16l-359.963 162.21z" fill="#298e97" transform="matrix(.11325 0 0 .11325 315.476915 -2.184355)"/></g></svg>';

//	if (urlParsedZilAddress) {
//		document.getElementById("mineraddress").innerHTML += '<h4 class="card-title">' + walletimg2 + urlParsedZilAddress + '</h4>';
//		//document.getElementById("mineraddress").style.fontSize = "25px";
//	}

    document.cookie = urlParsedAddress;
    getUrl("EVRpoolPAY/miners?method=" + urlParsedAddress).then(
        function (data) {
            document.getElementById("mineraddress").innerHTML = '<h4 class="card-title">' + walletimg + ' ' + urlParsedAddress + '</h4>';
            document.getElementById("currpending").innerHTML = evrimg + (data.payments.immature + data.payments.generate + data.payments.balances).toFixed(1) + ' EVR';
            document.getElementById("currpaid").innerHTML = evrimg + data.payments.paid.toFixed(1) + ' EVR';
            if (data.hashrate.solo === 0) {
                document.getElementById("workersonline").innerHTML = '<svg xmlns="http://www.w3.org/2000/svg" width="40" height="40" fill="white" class="bi bi-gpu-card" viewBox="0 0 16 16"><path d="M4 8a1.5 1.5 0 1 1 3 0 1.5 1.5 0 0 1-3 0Zm7.5-1.5a1.5 1.5 0 1 0 0 3 1.5 1.5 0 0 0 0-3Z"/><path d="M0 1.5A.5.5 0 0 1 .5 1h1a.5.5 0 0 1 .5.5V4h13.5a.5.5 0 0 1 .5.5v7a.5.5 0 0 1-.5.5H2v2.5a.5.5 0 0 1-1 0V2H.5a.5.5 0 0 1-.5-.5Zm5.5 4a2.5 2.5 0 1 0 0 5 2.5 2.5 0 0 0 0-5ZM9 8a2.5 2.5 0 1 0 5 0 2.5 2.5 0 0 0-5 0Z"/><path d="M3 12.5h3.5v1a.5.5 0 0 1-.5.5H3.5a.5.5 0 0 1-.5-.5v-1Zm4 1v-1h4v1a.5.5 0 0 1-.5.5h-3a.5.5 0 0 1-.5-.5Z"/>\n' +
                                '\t\t\t\t\t</svg>' + ' ' + (data.workers.shared.length) + ' Workers';
            }
            if (data.hashrate.solo !== 0) {
                let soloworkercount = 0;
                for (let i = 0; i < data.workers.solo.length; i++) {
                    document.getElementById("tablebody-solo").innerHTML = '<tr><th>Solo Workers</th><th>Hashrate</th><th>Work</th><th>Valid</th><th>Invalid</th><th>Stale</th></tr>';
                    getUrl("EVRpoolPAY/workers?method=" + data.workers.solo[i]).then(
                        function (worker) {
                            if (worker.hashrate.solo > 0) {
                                workers = '<td>' + data.workers.solo[i] + '</td>';
                                hash = '<td>' + hps(worker.hashrate.solo) + '</td>';
                                work = '<td>' + worker.work.solo.toFixed(2) + '</td>';
                                valid = '<td>' + worker.shares.solo.valid + '</td>';
                                invalid = '<td>' + worker.shares.solo.invalid + '</td>';
                                stale = '<td>' + worker.shares.solo.stale + '</td>';
                                row = '<tr>' + workers + hash + work + valid + invalid + stale + '</tr>';
                                document.getElementById("tablebody-solo").innerHTML += row;
                                soloworkercount = soloworkercount + 1;
                            }
                            document.getElementById("workersonline").innerHTML = '<svg xmlns="http://www.w3.org/2000/svg" width="40" height="40" fill="white" class="bi bi-gpu-card" viewBox="0 0 16 16"><path d="M4 8a1.5 1.5 0 1 1 3 0 1.5 1.5 0 0 1-3 0Zm7.5-1.5a1.5 1.5 0 1 0 0 3 1.5 1.5 0 0 0 0-3Z"/><path d="M0 1.5A.5.5 0 0 1 .5 1h1a.5.5 0 0 1 .5.5V4h13.5a.5.5 0 0 1 .5.5v7a.5.5 0 0 1-.5.5H2v2.5a.5.5 0 0 1-1 0V2H.5a.5.5 0 0 1-.5-.5Zm5.5 4a2.5 2.5 0 1 0 0 5 2.5 2.5 0 0 0 0-5ZM9 8a2.5 2.5 0 1 0 5 0 2.5 2.5 0 0 0-5 0Z"/><path d="M3 12.5h3.5v1a.5.5 0 0 1-.5.5H3.5a.5.5 0 0 1-.5-.5v-1Zm4 1v-1h4v1a.5.5 0 0 1-.5.5h-3a.5.5 0 0 1-.5-.5Z"/>\n' +
                                '\t\t\t\t\t</svg>' + ' ' + soloworkercount + ' Workers';
                        },
                        function (error) {
                        }
                    );
                }
            }
            for (let i = 0; i < data.workers.shared.length; i++) {
                document.getElementById("tablebody-shared").innerHTML = '<tr><th>Pool Workers</th><th>Hashrate</th><th>Work</th><th>Valid</th><th>Invalid</th><th>Stale</th></tr>';
                getUrl("EVRpoolPAY/workers?method=" + data.workers.shared[i]).then(
                    function (worker) {
                        workers = '<td>' + data.workers.shared[i] + '</td>';
                        hash = '<td>' + hps(worker.hashrate.shared) + '</td>';
                        work = '<td>' + worker.work.shared.toFixed(2) + '</td>';
                        valid = '<td>' + worker.shares.shared.valid + '</td>';
                        invalid = '<td>' + worker.shares.shared.invalid + '</td>';
                        stale = '<td>' + worker.shares.shared.stale + '</td>';
                        row = '<tr>' + workers + hash + work + valid + invalid + stale + '</tr>';
                        document.getElementById("tablebody-shared").innerHTML += row;
                    },
                    function (error) { /* code if some error */ }
                );
            }
			if (data.hashrate.shared + data.hashrate.solo === 0) {
                document.getElementById("currenthash").innerHTML = hps(0);
            }
            if (data.hashrate.shared + data.hashrate.solo !== null) {
                getUrl("EVRpoolPAY/historical?method=" + urlParsedAddress).then(
                    function (data2) {
                        console.log(data2);
                        let n = 0;
						let sum_p = 0;
						let sum_diff = 0;
						if (data2.length >= 5) {
						    for (let i = (data2.length-5); i < data2.length; i++) {
							sum_p += (data2[i].hashrate.shared + data2[i].hashrate.solo);
							//console.log(data2[i].hashrate.shared + data2[i].hashrate.solo);
							sum_diff += data2[i].network.difficulty;
							n++;
						}
                        }
						else if (data2.length < 5) {
						    for (let i = (data2.length); i < data2.length; i++) {
							sum_p += (data2[i].hashrate.shared + data2[i].hashrate.solo);
							//console.log(data2[i].hashrate.shared + data2[i].hashrate.solo);
							sum_diff += data2[i].network.difficulty;
							n++;
						}
                        }
						let hashnow = (data.hashrate.shared + data.hashrate.solo);
						console.log(data.hashrate.shared + data.hashrate.solo);
						let hashrate = ((sum_p + hashnow) / (n + 1));
						console.log(hashrate);
						console.log(n);
						console.log(sum_diff);
						let diff = sum_diff / n;
						let coin = calc(hashrate, 24, diff, 0.01);

                            if (n === 0) {
                                document.getElementById("est_earnings").innerHTML = evrimg + ' Estimate Pending';
                            }
                            else if (n !== 0) {
                                document.getElementById("est_earnings").innerHTML = evrimg + coin.toFixed(1) + ' EVR';
                            }

						if (data.hashrate.shared + data.hashrate.solo === 0) {
							document.getElementById("currenthash").innerHTML += ' ' + hps(0);
						}
						if (data.hashrate.shared + data.hashrate.solo !== 0) {
							document.getElementById("currenthash").innerHTML += ' ' + hps(hashrate);
						}

						base = Date.now();
                        let avrg = new Array(48);
                        let ypoolhash = new Array(48);
                        let ysolohash = new Array(48);
                        let ytotalhash = new Array(48);
                        let xtime = new Array(48);
                        for (let i = 0; i < 48; i++) {
                            xtime[i] = timetodate(data2[0].time - (1800000 * i));
                        }
                        ytotalhash.fill(0);
                        ypoolhash.fill(0);
                        ysolohash.fill(0);
                        avrg.fill(0);

                        for (let i = 0; i < data2.length; i++) {

                        	let startPoint = Math.floor((data2[data2.length - 1].time - data2[0].time) / 1800000);
								for (let i = 0; i < 48; i++) {
									xtime[i] = timetodate(data2[0].time - (1800000 * (i - startPoint)));
								}

                            let index = Math.floor((base - data2[i].time) / 1800000);
                            //console.log(index);
                            xtime.splice(index, 1, timetodate(data2[i].time));
                            ytotalhash.splice(index, 1, ((data2[i].hashrate.shared + data2[i].hashrate.solo) / 1000000).toFixed(2));
                            ypoolhash.splice(index, 1, (data2[i].hashrate.shared / 1000000).toFixed(2));
                            ysolohash.splice(index, 1, (data2[i].hashrate.solo / 1000000).toFixed(2));
                            avrg.splice(index, 1, hashrate);
                        }
                        if (ytotalhash[0] == 0) {
                            ytotalhash[0] = ((data.hashrate.shared + data.hashrate.solo) / 1000000).toFixed(2);
                        }
                        if (ypoolhash[0] == 0) {
                            ypoolhash[0] = (data.hashrate.shared / 1000000).toFixed(2);
                        }
                        if (ysolohash[0] == 0) {
                            ysolohash[0] = (data.hashrate.solo / 1000000).toFixed(2);
                        }

						const hashchart = document.getElementById('minerhash-chart');
                        new Chart(hashchart, {
                            type: "line",
                            data: {
                                labels: xtime.reverse(),
                                datasets: [
                                    {
                                        label: 'Pool Hashrate',
                                        borderColor: "rgba(93, 47, 134, 1)",
                                        backgroundColor: "rgba(93, 47, 134, 0.5)",
                                        data: ypoolhash.reverse()
                                    },
                                    {
                                        label: 'Solo Hashrate',
                                        borderColor: "rgba(211, 46, 157, 1)",
                                        backgroundColor: "rgba(211, 46, 157, 0.5)",
                                        data: ysolohash.reverse()
                                    },
                                    {
                                        label: 'Total Hashrate',
                                        borderColor: "rgba(227, 55, 70, 0.70)",
                                        backgroundColor: "rgba(227, 55, 70, 0)",
                                        data: ytotalhash.reverse()
                                    },
                                ]
                            },
                            options: {}
                        });

                    },
                    function (error) { /* code if some error */ }
                );
            }
        },
		function (error) { /* code if some error */ }
    );



	//ZIL STUFF
	if (urlParsedZilAddress) {
		console.log(urlParsedZilAddress);

    	getZilUrl(urlParsedZilAddress, "hashrate").then(
        	function (data) {
        	    if (urlParsedZilAddress) {
                    document.getElementById("mineraddress").innerHTML += '<h4 class="card-title">' + walletimg2 + urlParsedZilAddress + '</h4>';
                    //document.getElementById("mineraddress").style.fontSize = "25px";
                }
            	//console.log(data.average_hashrate);
            	//let hashrateZil = data.average_hashrate.toString();
            	getZilUrl(data.average_hashrate, "calculator").then(
                	function (data2) {
						//console.log(data2);
						document.getElementById("est_earningszil").innerHTML = zilimg + data2.zil + ' ZIL';
                    	//estimates are all in 24hour frame can be changed in future from 1 to 30 days
                    	//console.log(data2.diff_in_usd); //Estiamte USD Value From mining zil
                    	//console.log(data2.zil); //Estiamte zil From mining
                	},
                	function (error) {}
            	);
        	},
        	function (error) {}
    	);

    	getZilUrl(urlParsedZilAddress, "balance").then(
        	function (data) {
            	//console.log(data);
				document.getElementById("currpendingzil").innerHTML = zilimg + data.zil.toFixed(3) + ' ZIL';
				//console.log(data.zil_min_payout);
				document.getElementById("zilmin").innerHTML = '* ' + data.zil_min_payout + ' ZIL Minimum, Payouts are not handled by evrpool';
				document.getElementById("zilminstyle").style.marginBottom = "-2px";
        	},
        	function (error) {}
    	);

    	getZilUrl(urlParsedZilAddress, "payouts").then(
        	function (data) {
            	//console.log(data);
				document.getElementById("currpaidzil").innerHTML = zilimg + data.total_amount.toFixed(3) + ' ZIL';
        	},
        	function (error) {}
    	);
	}