
    getUrl("EVRpoolPAY/historical").then(
        function (data) {
            let xval = new Array();
            let yval1 = new Array();
            let yval2 = new Array();
            for (let i = 0; i < data.length; i++) {
                yval1.push(data[i].network.hashrate / 1000000000);
                yval2.push(data[i].network.difficulty.toFixed(2));
                xval.push(timetodate(data[i].time));
            }

            new Chart("nethash", {
                type: "line",
                data: {
                    labels: xval,
                    datasets: [{
                        label: 'Network Hashrate (GH/s)',
                        backgroundColor: "rgba(93, 47, 134, 0.5)",
                        borderColor: "rgba(211, 46, 157, 1)",
                        data: yval1,
						fill: true,
						lineTension: 0.4
                    }]
                },
                options: {
                    scales: {
						xAxes: {
							ticks: {
								display: true, //this will remove only the label
							},
						}
					},
                	plugins: {
						legend: {
							display: false,
							position: 'bottom',
							padding: {
									left: 16,
									right: 16,
								},
							margin: {
									left: 16,
									right: 16,
								},
						},
					},
					elements: {
						point: {
							radius: 0.1
						}
					}
				}
            });

            new Chart("netdiff", {
                type: "line",
                data: {
                    labels: xval,
                    datasets: [{
                        label: 'Network Difficulty',
                        backgroundColor: "rgba(211, 46, 157, 0.5)",
                        borderColor: "rgba(93, 47, 134, 1)",
                        data: yval2,
						fill: true,
						lineTension: 0.4
                    }]
                },
                options: {
                    scales: {
						xAxes: {
							ticks: {
								display: true, //this will remove only the label
							},
						}
					},
                	plugins: {
						legend: {
							display: false,
							position: 'bottom',
							padding: {
									left: 16,
									right: 16,
								},
							margin: {
									left: 16,
									right: 16,
								},
						},
					},
					elements: {
						point: {
							radius: 0.1
						}
					}
				}
            });
        },
        function (error) { /* code if some error */ }
    );
    getUrl("EVRpoolPAY").then(
        function (data) {
            document.getElementById("currdiff").innerHTML += data.network.difficulty.toFixed(2);
            document.getElementById("currhash").innerHTML += hps(data.network.hashrate);
        },
        function (error) { /* code if some error */ }
    );