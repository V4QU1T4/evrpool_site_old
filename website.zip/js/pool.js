
    getUrl("EVRpool").then(
        function (data) {

        	let currenttime = Date.now();
			let countdown = data.payments.next - currenttime;
			setInterval(()=>{
				if (countdown > 0) {
					countdown -= 1000;
				document.getElementById("nextpayment").innerHTML = timetotime(countdown);
				} else {
					countdown = 30 * 60000;
				}
			}, 1000);

			let currentHashrate = (data.hashrate.shared + data.hashrate.solo);
			let currentDifficulty = data.network.difficulty;
            document.getElementById("currhash").innerHTML = hps(data.hashrate.shared + data.hashrate.solo);
			//window.curr_pool_hash = hps(data.hashrate.shared);
			//window.curr_solo_hash = hps(data.hashrate.solo);
			document.getElementById("currminers").innerHTML += ' ' + data.status.miners + ' Miners';
			document.getElementById("currworkers").innerHTML += ' ' + data.status.workers + ' Workers';

			// TTF
            let TTF = (currentDifficulty * 2**32) / currentHashrate / 60; //in minutes
			document.getElementById("ttf").innerHTML = TTF.toFixed(0) + ' minutes';
        },
        function (error) { /* code if some error */ }
    );

    getUrl("EVRpool/payments?method=records").then(
        function (data) {
			document.getElementById("lastpayment").innerHTML = data[0].paid.toFixed(0) + ' EVR';
        },
        function (error) { /* code if some error */ }
    );

// Recent Blocks
    getUrl("EVRpool/blocks?method=confirmed").then(
        function (data) {
            let xval2 = new Array();
            let yval3 = new Array();
            let yval4 = new Array();
            let ydiff = new Array();

            let good = new Array();
            let okay = new Array();
            let poor = new Array();
            let bad = new Array();


            let twentyfourhr = currenttime - 86400000;
            console.log(timetodate(twentyfourhr));
            let blockcount = 0;
			// && data[i].time >= twentyfourhr
            for (let i = 0; i < data.length; i++) {
            	area = '🇺🇸';
            	block = '<td>' + data[i].height + '</td>';
				time = '<td>' + timetodate(data[i].time) + '</td>';
				minertd= '<td id="' + i + '">';
				miner = minertd + '<a class="link-primary" href="./workers.html?=" onclick="location.href= this.href + this.innerHTML;return false;">' + data[i].worker + '</a>' + '</td>';

				if (data[i].identifier === 'main') {
					area = '🇺🇸';
				}
				if (data[i].identifier === 'eu') {
					area = '🇩🇪';
				}
				if (data[i].identifier === 'asia') {
					area = '🇸🇬';
				}
				if (data[i].solo === true) {
					pool = '[SOLO]';
					server = '<td style="color: #d32e9d">' + area + ' ' + pool + '</td>';
					yval4.push(data[i].luck);
					xval2.push(data[i].height);
					yval3.push(null);
				}
				if (data[i].solo === false) {
					pool = '[POOL]';
					server = '<td style="color: #5d2f86">' + area + ' ' + pool + '</td>';
					yval3.push(data[i].luck);
					xval2.push(data[i].height);
					yval4.push(null);
				}
				if (data[i].luck <= 100) {
						luck = '<td style="color: #14d60a; border-color: #FFFFFF">' + data[i].luck.toFixed(2) + '%' + '</td>';
						good.push(data[i].luck);
						okay.push(data[i].null);
						poor.push(data[i].null);
						bad.push(data[i].null);
					}
				if (data[i].luck > 100 && data[i].luck < 200) {
						luck = '<td style="color: #d0d61c; border-color: #FFFFFF">' + data[i].luck.toFixed(2) + '%' + '</td>';
						good.push(data[i].null);
						okay.push(data[i].luck);
						poor.push(data[i].null);
						bad.push(data[i].null);
					}
				if (data[i].luck > 200 && data[i].luck < 300) {
						luck = '<td style="color: #d68428; border-color: #FFFFFF">' + data[i].luck.toFixed(2) + '%' + '</td>';
						good.push(data[i].null);
						okay.push(data[i].null);
						poor.push(data[i].luck);
						bad.push(data[i].null);
					}
				if (data[i].luck > 300) {
						luck = '<td style="color: #d61c10; border-color: #FFFFFF">' + data[i].luck.toFixed(2) + '%' + '</td>';
						good.push(data[i].null);
						okay.push(data[i].null);
						poor.push(data[i].null);
						bad.push(data[i].luck);
					}
				ydiff.push(data[i].difficulty / 1000);
				difficulty = '<td>' + (data[i].difficulty / 1000).toFixed(2) + 'k' + '</td>';

				if (data[i].time >= twentyfourhr) {
						blockcount++;
						row = '<tr>' + block + time + miner + luck + difficulty + server + '</tr>';
						document.getElementById("tableconfirmed").innerHTML += row;
						console.log(blockcount);
					}
            }

            document.getElementById("blockstoday").innerHTML = blockcount;

            let n = 0;
            let sum_p = 0;
			yval3.forEach(x => {
				if (x !== null) {
					sum_p += x;
					n++;
				}
			});
			document.getElementById("currluck").innerHTML = (sum_p / n).toFixed(2) + '%';

			let o = 0;
            let sum_s = 0;
			yval4.forEach(x => {
				if (x !== null) {
					sum_s += x;
					o++;
				}
			});
			//document.getElementById("currsololuck").innerHTML = (sum_s / o).toFixed(2) + '%';

            new Chart("luck", {
                data: {
                	labels: xval2.reverse(),
                    datasets:
					[
                    	{
                    	barPercentage: 1,
						categoryPercentage: 1,
                    	type: "bar",
                        label: 'Luck <100%',
							yAxisID: 'A',
                        borderColor: "rgba(55, 333, 100, 0.75)",
							backgroundColor: "rgba(55, 333, 100, 0.75)",
							spanGaps: true,
                        data: good.reverse()
                    	},
                    	{
                    	barPercentage: 1,
						categoryPercentage: 1,
                    	type: "bar",
                        label: '100-200% Luck',
							yAxisID: 'A',
                        borderColor: "rgba(255, 222, 157, 1)",
							backgroundColor: "rgba(255, 222, 157, 1)",
							spanGaps: true,
                        data: okay.reverse()
                    	},
						{
						barThickness: 'flex',
						barPercentage: 1,
						categoryPercentage: 1,
						type: "bar",
                        label: '200-300% Luck',
						yAxisID: 'A',
                        borderColor: "rgba(444, 111, 111, 1)",
						backgroundColor: "rgba(444, 111, 111, 1)",
						spanGaps: true,
                        data: poor.reverse()
                    	},
						{
						barThickness: 'flex',
						type: "bar",
                        label: 'Luck >300%',
						yAxisID: 'A',
                        borderColor: "rgba(333, 12, 33, 1)",
						backgroundColor: "rgba(333, 12, 33, 1)",
						spanGaps: true,
                        data: bad.reverse()
                    	},
						//{
						//type: "line",
						//fill: true,
                        //label: 'Pool',
						//	yAxisID: 'A',
                        //borderColor: "rgba(93, 47, 134, 0.5)",
						//	backgroundColor: "rgba(93, 47, 134, 0.5)",
                        //data: yval3.reverse(),
						//	spanGaps: true,
						//lineTension: 0.4
                    	//},
                    	//{
						//type: "line",
						//fill: true,
                        //label: 'Solo',
						//	yAxisID: 'A',
                        //borderColor: "rgba(211, 46, 157, 0.5)",
						//	backgroundColor: "rgba(211, 46, 157, 0.5)",
                        //data: yval4.reverse(),
						//	spanGaps: true,
						//lineTension: 0.4
                    	//},
						{
						type: "line",
						fill: false,
                        label: 'Network Difficulty',
							yAxisID: 'B',
                        borderColor: "rgba(102, 220, 160, 0.75)",
							backgroundColor: "rgba(102, 220, 160, 0.20)",
                        data: ydiff.reverse(),
						lineTension: 0.4
                    	}
                    ],
                },
                options: {
					scales: {
						A: {
							type: 'linear',
							position: 'left',
							grid: {
								color: "rgba(255, 255, 255, 0.5)",
								display: true,
							},
							//ticks: {
							//	max: 5,
							//	min: 0
							//}
						},
						B: {
							type: 'linear',
							position: 'right',
							//ticks: {
							//	max: 5,
							//	min: 0
							//}
						},
						xAxes: {
							ticks: {
								display: true, //this will remove only the label
							},
						}
					},
					plugins: {
						legend: {
							display: true,
							position: 'bottom',
							padding: {
									left: 16,
									right: 16,
								},
							margin: {
									left: 16,
									right: 16,
								},
						},
					},
					elements: {
						point: {
							radius: 0.5
						}
					}
				}
            });
        },
        function (error) { /* code if some error */ }
    );

	getUrl("EVRpool/blocks?method=pending").then(
        function (data) {
			for (let i = 0; i < data.length; i++) {
				block = '<td>' + data[i].height + '</td>';
				time = '<td>' + timetodate(data[i].time) + '</td>';
				minertd= '<td id="' + i + '">';
				miner = minertd + '<a class="link-primary" href="./workers.html?=" onclick="location.href= this.href + this.innerHTML;return false;">' + data[i].worker + '</a>' + '</td>';
				if (data[i].identifier === 'main') {
					area = '🇺🇸';
				}
				if (data[i].identifier === 'eu') {
					area = '🇩🇪';
				}
				if (data[i].identifier === 'ap') {
					area = '🇸🇬';
				}
				if (data[i].solo === true) {
					pool = '[SOLO]';
					server = '<td style="color: #d32e9d; border-color: #FFFFFF">' + area + ' ' + pool + '</td>';
				}
				if (data[i].solo === false) {
					pool = '[POOL]';
					server = '<td style="color: #5d2f86; border-color: #FFFFFF">' + area + ' ' + pool + '</td>';
				}
				if (data[i].luck < 100) {
						luck = '<td style="color: #14d60a; border-color: #FFFFFF">' + data[i].luck.toFixed(2) + '%' + '</td>';
					}
				if (data[i].luck > 100 && data[i].luck < 200) {
						luck = '<td style="color: #d0d61c; border-color: #FFFFFF">' + data[i].luck.toFixed(2) + '%' + '</td>';
					}
				if (data[i].luck > 200 && data[i].luck < 300) {
						luck = '<td style="color: #d68428; border-color: #FFFFFF">' + data[i].luck.toFixed(2) + '%' + '</td>';
					}
				if (data[i].luck > 300) {
						luck = '<td style="color: #d61c10; border-color: #FFFFFF">' + data[i].luck.toFixed(2) + '%' + '</td>';
					}
				difficulty = '<td>' + (data[i].difficulty / 1000).toFixed(2) + 'k' + '</td>';
				row = '<tr>' + block + time + miner + luck + difficulty + server + '</tr>';
				document.getElementById("tablepending").innerHTML += row;
			}
		});

// Pool Hashrate Chart + TTF
    getUrl("EVRpool/historical").then(
        function (data) {
            let xval = new Array();
            let yval1 = new Array();
            let yval2 = new Array();

            let avrgpoolhash = 0;
    		let avrgnetdiff = 0;

            for (let i = 1; i < data.length; i++) {
                yval1.push(((data[i].hashrate.shared + data[i-1].hashrate.shared) / 2) / 1000000000);
                yval2.push(((data[i].hashrate.solo + data[i-1].hashrate.solo) / 2) / 1000000000);
                xval.push(timetodate(data[i].time));

                avrgpoolhash += data[i].hashrate.shared;
        		avrgnetdiff += data[i].network.difficulty;
            }

            // TTF
			// console.log(avrgnetdiff);
            // console.log(avrgpoolhash);
            // let TTF = (avrgnetdiff * 2**32) / avrgpoolhash / 60; //in minutes
			// document.getElementById("ttf").innerHTML = TTF.toFixed(0) + ' minutes';

			new Chart("poolhash", {
                type: "line",
                data: {
                    labels: xval,
                    datasets: [
						{
                        label: 'POOL ' + '(' + hps(data[data.length - 1].hashrate.shared) + ')',
							yAxisID: 'B',
							fill: true,
                        borderColor: "rgba(93, 47, 134, 1)",
							backgroundColor: "rgba(93, 47, 134, 0.5)",
                        data: yval1,
						lineTension: 0.4
                    	},
						{
                        label: 'SOLO ' + '(' + hps(data[data.length - 1].hashrate.solo) + ')',
							yAxisID: 'B',
							fill: true,
                        borderColor: "rgba(211, 46, 157, 1)",
							backgroundColor: "rgba(211, 46, 157, 0.5)",
                        data: yval2,
						lineTension: 0.4
                    	}
					]
                },
                options: {
					scales: {
						B: {
							type: 'linear',
							position: 'left',
							grid: {
								color: "rgba(255, 255, 255, 0.5)",
								display: true,
							},
						},
						xAxes: {
							ticks: {
								display: true, //this will remove only the label
							},
						}
					},
					plugins: {
						title: {
								display: false,
								text: 'Hashrate ',
							},
						legend: {
							display: true,
							position: 'bottom',
							padding: {
									left: 16,
									right: 16,
								},
							margin: {
									left: 16,
									right: 16,
								},
						},
					},
					//elements: {
					//	point: {
					//		radius: 0.5
					//	}
					//}
				}
            });
        },
        function (error) { /* code if some error */ }
    );