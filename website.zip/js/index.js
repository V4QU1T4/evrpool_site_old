<!-- Scripts -->

	getUrl("EVRpoolPAY").then(
		function(data) {
			document.getElementById("currdiff").innerHTML = data.network.difficulty.toFixed(2);
			document.getElementById("currnetwork").innerHTML = hps(data.network.hashrate);
			document.getElementById("currenthash").innerHTML = hps(data.hashrate.shared + data.hashrate.solo);
			document.getElementById("currminers").innerHTML = data.status.miners;
			document.getElementById("currworkers").innerHTML = data.status.workers;
			document.getElementById("currblocks").innerHTML = (data.blocks.valid + 24151); },
  		function(error) { /* code if some error */ }
	);

    getUrl("EVRpoolPAY/blocks?method=confirmed").then(
        function (data) {
            let yval3 = new Array();
            let yval4 = new Array();
            for (let i = 0; i < data.length; i++) {
				if (data[i].solo === true) {
					yval4.push(data[i].luck);
					yval3.push(null);
				}
				if (data[i].solo === false) {
					yval3.push(data[i].luck);
					yval4.push(null);
				}
            }

            console.log(yval3);
            console.log(yval4);

            let n = 0;
            let sum_p = 0;
			yval3.forEach(x => {
				if (x !== null) {
					sum_p += x;
					n++;
				}
			});
			document.getElementById("currluck").innerHTML = (sum_p / n).toFixed(2) + '%';
        },
        function (error) { /* code if some error */ }
    );

<!-- Script END -->