<!-- Scripts -->
	let nanominer = '<div class="row">\n' +
			'\t\t<div class="card" style="border-color: #00c4ff; margin-top: 32px; margin-bottom: 32px">\n' +
			'\t\t\t<div class="card-body">\n' +
			'\t\t\t\t<div class="row">\n' +
			'\t\t\t\t\t<div class="col-10" style="text-align: left">\n' +
			'\t\t\t\t\t\t<h3><svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" fill="white" style="margin: 4px" class="bi bi-github" viewBox="0 0 16 16">\\n\' +<path d="M8 0C3.58 0 0 3.58 0 8c0 3.54 2.29 6.53 5.47 7.59.4.07.55-.17.55-.38 0-.19-.01-.82-.01-1.49-2.01.37-2.53-.49-2.69-.94-.09-.23-.48-.94-.82-1.13-.28-.15-.68-.52-.01-.53.63-.01 1.08.58 1.23.82.72 1.21 1.87.87 2.33.66.07-.52.28-.87.51-1.07-1.78-.2-3.64-.89-3.64-3.95 0-.87.31-1.59.82-2.15-.08-.2-.36-1.02.08-2.12 0 0 .67-.21 2.2.82.64-.18 1.32-.27 2-.27.68 0 1.36.09 2 .27 1.53-1.04 2.2-.82 2.2-.82.44 1.1.16 1.92.08 2.12.51.56.82 1.27.82 2.15 0 3.07-1.87 3.75-3.65 3.95.29.25.54.73.54 1.48 0 1.07-.01 1.93-.01 2.2 0 .21.15.46.55.38A8.012 8.012 0 0 0 16 8c0-4.42-3.58-8-8-8z"/>\n' +
			'\t\t\t\t\t\t</svg><a href="https://github.com/nanopool/nanominer/releases/tag/v3.7.6" class="link-primary">nanominer</a></h3>\n' +
			'\t\t\t\t\t</div>\n' +
			'\t\t\t\t\t<div class="col" style="text-align: right">\n' +
			'\t\t\t\t\t\t<svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" fill="green" style="margin: 4px" class="bi bi-nvidia" viewBox="0 0 16 16"><path d="M1.635 7.146S3.08 5.012 5.97 4.791v-.774C2.77 4.273 0 6.983 0 6.983s1.57 4.536 5.97 4.952v-.824c-3.23-.406-4.335-3.965-4.335-3.965ZM5.97 9.475v.753c-2.44-.435-3.118-2.972-3.118-2.972S4.023 5.958 5.97 5.747v.828h-.004c-1.021-.123-1.82.83-1.82.83s.448 1.607 1.824 2.07ZM6 2l-.03 2.017A6.64 6.64 0 0 1 6.252 4c3.637-.123 6.007 2.983 6.007 2.983s-2.722 3.31-5.557 3.31c-.26 0-.504-.024-.732-.065v.883c.195.025.398.04.61.04 2.638 0 4.546-1.348 6.394-2.943.307.246 1.561.842 1.819 1.104-1.757 1.47-5.852 2.657-8.173 2.657a6.84 6.84 0 0 1-.65-.034V14H16l.03-12H6Zm-.03 3.747v-.956a6.4 6.4 0 0 1 .282-.015c2.616-.082 4.332 2.248 4.332 2.248S8.73 9.598 6.743 9.598c-.286 0-.542-.046-.773-.123v-2.9c1.018.123 1.223.572 1.835 1.593L9.167 7.02s-.994-1.304-2.67-1.304a4.9 4.9 0 0 0-.527.031Z"/></svg>\n' +
			'\t\t\t\t\t\t<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="red" style="margin: 4px" class="bi bi-amd" viewBox="0 0 16 16"><path d="m.334 0 4.358 4.359h7.15v7.15l4.358 4.358V0H.334ZM.2 9.72l4.487-4.488v6.281h6.28L6.48 16H.2V9.72Z"/></svg>\n' +
			'\t\t\t\t\t</div>\n' +
			'\t\t\t\t\t<code class="text-muted" id="nanominerEVR"></code><code class="text-muted" id="nanominerZIL" hidden></code>\n' +
			'\t\t\t\t</div>\n' +
			'\t\t\t</div>\n' +
			'\t\t</div>\n' +
			'\t</div>';

	let wildrig = '<div class="row" id="wildrig">\n' +
			'\t\t<div class="card" style="border-color: #00c4ff; margin-top: 32px;">\n' +
			'\t\t\t<div class="card-body">\n' +
			'\t\t\t\t<div class="row">\n' +
			'\t\t\t\t\t<div class="col-10" style="text-align: left">\n' +
			'\t\t\t\t\t\t<h3><svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" fill="white" style="margin: 4px" class="bi bi-github" viewBox="0 0 16 16">\\n\' +<path d="M8 0C3.58 0 0 3.58 0 8c0 3.54 2.29 6.53 5.47 7.59.4.07.55-.17.55-.38 0-.19-.01-.82-.01-1.49-2.01.37-2.53-.49-2.69-.94-.09-.23-.48-.94-.82-1.13-.28-.15-.68-.52-.01-.53.63-.01 1.08.58 1.23.82.72 1.21 1.87.87 2.33.66.07-.52.28-.87.51-1.07-1.78-.2-3.64-.89-3.64-3.95 0-.87.31-1.59.82-2.15-.08-.2-.36-1.02.08-2.12 0 0 .67-.21 2.2.82.64-.18 1.32-.27 2-.27.68 0 1.36.09 2 .27 1.53-1.04 2.2-.82 2.2-.82.44 1.1.16 1.92.08 2.12.51.56.82 1.27.82 2.15 0 3.07-1.87 3.75-3.65 3.95.29.25.54.73.54 1.48 0 1.07-.01 1.93-.01 2.2 0 .21.15.46.55.38A8.012 8.012 0 0 0 16 8c0-4.42-3.58-8-8-8z"/>\n' +
			'\t\t\t\t\t\t</svg><a href="https://github.com/andru-kun/wildrig-multi/releases/tag/0.36.6b" class="link-primary">Wildrig</a></h3>\n' +
			'\t\t\t\t\t</div>\n' +
			'\t\t\t\t\t<div class="col" style="text-align: right"><svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" fill="green" style="margin: 4px" class="bi bi-nvidia" viewBox="0 0 16 16"><path d="M1.635 7.146S3.08 5.012 5.97 4.791v-.774C2.77 4.273 0 6.983 0 6.983s1.57 4.536 5.97 4.952v-.824c-3.23-.406-4.335-3.965-4.335-3.965ZM5.97 9.475v.753c-2.44-.435-3.118-2.972-3.118-2.972S4.023 5.958 5.97 5.747v.828h-.004c-1.021-.123-1.82.83-1.82.83s.448 1.607 1.824 2.07ZM6 2l-.03 2.017A6.64 6.64 0 0 1 6.252 4c3.637-.123 6.007 2.983 6.007 2.983s-2.722 3.31-5.557 3.31c-.26 0-.504-.024-.732-.065v.883c.195.025.398.04.61.04 2.638 0 4.546-1.348 6.394-2.943.307.246 1.561.842 1.819 1.104-1.757 1.47-5.852 2.657-8.173 2.657a6.84 6.84 0 0 1-.65-.034V14H16l.03-12H6Zm-.03 3.747v-.956a6.4 6.4 0 0 1 .282-.015c2.616-.082 4.332 2.248 4.332 2.248S8.73 9.598 6.743 9.598c-.286 0-.542-.046-.773-.123v-2.9c1.018.123 1.223.572 1.835 1.593L9.167 7.02s-.994-1.304-2.67-1.304a4.9 4.9 0 0 0-.527.031Z"/>\n' +
			'\t\t\t\t\t</svg><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="red" style="margin: 4px" class="bi bi-amd" viewBox="0 0 16 16"><path d="m.334 0 4.358 4.359h7.15v7.15l4.358 4.358V0H.334ZM.2 9.72l4.487-4.488v6.281h6.28L6.48 16H.2V9.72Z"/></svg>\n' +
			'\t\t\t\t\t</div>\n' +
			'\t\t\t\t\t<code class="text-muted" id="wildrigEVR">wildrig.exe --algo evrprogpow --url stratum+tcp://us.evrpool.com:1111 --user YOUR_EVR_ADDRESS_HERE.worker --pass x</code>\n' +
			'\t\t\t\t</div>\n' +
			'\t\t\t</div>\n' +
			'\t\t</div>\n' +
			'\t</div>';



	let EVRlocation = 'us.evrpool.com';
	let EVRport = ':1111';
	let EVRpool = EVRlocation + EVRport;
	let EVRwallet = 'YOUR_EVR_ADDRESS_HERE ';

	let wildrigEVR = 'wildrig.exe ' + '--algo Evrprogpow ' + '--url ' + 'stratum+tcp://' + EVRpool + ' --user ' + EVRwallet + '--pass x';
	let nanominerEVR = 'nanominer.exe ' + '-algo Evrprogpow ' + '-wallet ' + EVRwallet +  '-pool1 ' + EVRpool;

	let ZILlocation = 'us-east.ezil.me:4444';
	let ZILwallet = 'YOUR_ZIL_ADDRESS ';

	let nanominerZIL = '-algo zil ' + '-wallet ' + ZILwallet +  '-pool1 ' + ZILlocation;

	function updatelocation () {
		if (document.getElementById('EU').checked === true) {
			EVRlocation = 'eu.evrpool.com';
			ZILlocation = 'eu.ezil.me:4444';
			EVRpool = EVRlocation + EVRport;
			document.getElementById("serverlocation").innerHTML = EVRlocation;
			document.getElementById("zillocation").innerHTML = ZILlocation;
			nanominerEVR = 'nanominer.exe ' + '-algo Evrprogpow ' + '-wallet ' + EVRwallet +  '-pool1 ' + EVRpool;
			document.getElementById("nanominerEVR").innerHTML = nanominerEVR;
			nanominerZIL = '-algo zil ' + '-wallet ' + ZILwallet +  '-pool1 ' + document.getElementById("zillocation").innerHTML;
			document.getElementById("nanominerZIL").innerHTML = nanominerZIL;
			wildrigEVR = 'wildrig.exe ' + '--algo Evrprogpow ' + '--url ' + 'stratum+tcp://' + document.getElementById("serverlocation").innerHTML + document.getElementById("serverport").innerHTML + ' --user ' + EVRwallet + '--pass x';
			document.getElementById("wildrigEVR").innerHTML = wildrigEVR;
		}
		else if (document.getElementById('US').checked === true) {
			EVRlocation = 'us.evrpool.com';
			ZILlocation = 'us-east.ezil.me:4444';
			EVRpool = EVRlocation + EVRport;
			document.getElementById("serverlocation").innerHTML = EVRlocation;
			document.getElementById("zillocation").innerHTML = ZILlocation;
			nanominerEVR = 'nanominer.exe ' + '-algo Evrprogpow ' + '-wallet ' + EVRwallet +  '-pool1 ' + EVRpool;
			document.getElementById("nanominerEVR").innerHTML = nanominerEVR;
			nanominerZIL = '-algo zil ' + '-wallet ' + ZILwallet +  '-pool1 ' + document.getElementById("zillocation").innerHTML;
			document.getElementById("nanominerZIL").innerHTML = nanominerZIL;
			wildrigEVR = 'wildrig.exe ' + '--algo Evrprogpow ' + '--url ' + 'stratum+tcp://' + document.getElementById("serverlocation").innerHTML + document.getElementById("serverport").innerHTML + ' --user ' + EVRwallet + '--pass x';
			document.getElementById("wildrigEVR").innerHTML = wildrigEVR;
		}
		else if (document.getElementById('AP').checked === true) {
			EVRlocation = 'ap.evrpool.com';
			ZILlocation = 'asia.ezil.me:4444';
			EVRpool = EVRlocation + EVRport;
			document.getElementById("serverlocation").innerHTML = EVRlocation;
			document.getElementById("zillocation").innerHTML = ZILlocation;
			nanominerEVR = 'nanominer.exe ' + '-algo Evrprogpow ' + '-wallet ' + EVRwallet +  '-pool1 ' + EVRpool;
			document.getElementById("nanominerEVR").innerHTML = nanominerEVR;
			nanominerZIL = '-algo zil ' + '-wallet ' + ZILwallet +  '-pool1 ' + document.getElementById("zillocation").innerHTML;
			document.getElementById("nanominerZIL").innerHTML = nanominerZIL;
			wildrigEVR = 'wildrig.exe ' + '--algo Evrprogpow ' + '--url ' + 'stratum+tcp://' + document.getElementById("serverlocation").innerHTML + document.getElementById("serverport").innerHTML + ' --user ' + EVRwallet + '--pass x';
			document.getElementById("wildrigEVR").innerHTML = wildrigEVR;
		}
	}
	function updateport () {
		if (document.getElementById('PoolPort').checked === true) {
			EVRport = ':1111';
			EVRpool = EVRlocation + EVRport;
			document.getElementById("serverport").innerHTML = EVRport;
			nanominerEVR = 'nanominer.exe ' + '-algo Evrprogpow ' + '-wallet ' + EVRwallet +  '-pool1 ' + EVRpool;
			document.getElementById("nanominerEVR").innerHTML = nanominerEVR;
			wildrigEVR = 'wildrig.exe ' + '--algo Evrprogpow ' + '--url ' + 'stratum+tcp://' + document.getElementById("serverlocation").innerHTML + document.getElementById("serverport").innerHTML + ' --user ' + EVRwallet + '--pass x';
			document.getElementById("wildrigEVR").innerHTML = wildrigEVR;
		}
		else if (document.getElementById('SoloPort').checked === true) {
			EVRport = ':5010';
			EVRpool = EVRlocation + EVRport;
			document.getElementById("serverport").innerHTML = EVRport;
			nanominerEVR = 'nanominer.exe ' + '-algo Evrprogpow ' + '-wallet ' + EVRwallet +  '-pool1 ' + EVRpool;
			document.getElementById("nanominerEVR").innerHTML = nanominerEVR;
			wildrigEVR = 'wildrig.exe ' + '--algo Evrprogpow ' + '--url ' + 'stratum+tcp://' + document.getElementById("serverlocation").innerHTML + document.getElementById("serverport").innerHTML + ' --user ' + EVRwallet + '--pass x';
			document.getElementById("wildrigEVR").innerHTML = wildrigEVR;
		}
	}

	function updateEVR() {
    EVRwallet = document.getElementById('inputEVRAddress').value + ' ';
    nanominerEVR = 'nanominer.exe ' + '-algo Evrprogpow ' + '-wallet ' + EVRwallet +  '-pool1 ' + EVRpool;
    document.getElementById("nanominerEVR").innerHTML = nanominerEVR;
    wildrigEVR = 'wildrig.exe ' + '--algo Evrprogpow ' + '--url ' + 'stratum+tcp://' + document.getElementById("serverlocation").innerHTML + document.getElementById("serverport").innerHTML + ' --user ' + EVRwallet + '--pass x';
    document.getElementById("wildrigEVR").innerHTML = wildrigEVR;
	}

	function updateZIL() {
    ZILwallet = document.getElementById('inputZILAddress').value + ' ';
    nanominerZIL = '-algo zil ' + '-wallet ' + ZILwallet +  '-pool1 ' + document.getElementById("zillocation").innerHTML;
    document.getElementById("nanominerZIL").innerHTML = nanominerZIL;
    wildrigEVR = 'wildrig.exe ' + '--algo Evrprogpow ' + '--url ' + 'stratum+tcp://' + document.getElementById("serverlocation").innerHTML + document.getElementById("serverport").innerHTML + ' --user ' + EVRwallet + '--pass x';
    document.getElementById("wildrigEVR").innerHTML = wildrigEVR;
	}

	function changeCoin() {
		if (document.getElementById("coinSelect").value === '1'){
			document.getElementById("miners").innerHTML = wildrig + nanominer;
			document.getElementById("nanominerEVR").innerHTML = nanominerEVR;
			document.getElementById("nanominerZIL").innerHTML = nanominerZIL;
			document.getElementById("wildrig").setAttribute("hidden", true);
			document.getElementById("nanominerZIL").removeAttribute("hidden");
			document.getElementById("ZILwalletinput").removeAttribute("hidden");
		}
		else if (document.getElementById("coinSelect").value === '2') {
			document.getElementById("miners").innerHTML = wildrig + nanominer;
			document.getElementById("nanominerEVR").innerHTML = nanominerEVR;
			document.getElementById("wildrig").removeAttribute("hidden");
			document.getElementById("nanominerZIL").setAttribute("hidden", true);
			document.getElementById("ZILwalletinput").setAttribute("hidden", true);
		}
	}