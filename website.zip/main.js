const baseURL = "https://evrpool.com/api/";
async function getUrl(url) {
    let response = await fetch(baseURL + url);
    let data = await response.json();
    return data.body.primary
}

let myAddress = document.cookie;

let currenttime = Date.now();
function timetodate(unixtimestamp) {
					let date = new Date(unixtimestamp);
					let hours = date.getHours();
					let minutes = "0" + date.getMinutes();
					//let seconds = "0" + date.getSeconds();
					let formattedTime = hours + ':' + minutes.substr(-2);
					//console.log(formattedTime);
					return formattedTime
				}
function timetotime(unixtime) {
					let date1 = new Date(unixtime);
					let hours = date1.getHours();
					let min = "0" + date1.getMinutes();
					let sec = "0" + date1.getSeconds();
					let convertedtime = hours + 'hrs' + ' ' + min.substr(-2) + 'min' + ' ' + sec.substr(-2) + 's';
					return convertedtime
				}


function hps(hashpersecond) {
    let units = 'H/s';
    if (hashpersecond > 1000) {
        hashpersecond /= 1000;
        units = 'kH/s';
    }
    if (hashpersecond > 1000) {
        hashpersecond /= 1000;
        units = 'MH/s';
    }
    if (hashpersecond > 1000) {
        hashpersecond /= 1000;
        units = 'GH/s';
    }
    if (hashpersecond > 1000) {
        hashpersecond /= 1000;
        units = 'TH/s';
    }
    return hashpersecond.toFixed(2) + ' ' + units;
}

function calc(hashrate, timeHours, diff, fee) {
    let blockReward = 2500.2 * 1 - fee;
    let coin = (hashrate * blockReward * (60 * 60 * timeHours)) / (diff * (2**32));
    console.log(coin);
    return coin;
}

async function getZilUrl(zilAddress, option) {
    let response = null;
    let data = null;
    switch (option) {
        case "hashrate": //hashrate
            response = await fetch("https://stats.ezil.me/current_stats/0xffffffffffffffffffffffffffffffffffffffff." + zilAddress + "/reported");
            data = await response.json();
            return data.etc;
        case "balance": //balance
            response = await fetch("https://billing.ezil.me/balances/0xffffffffffffffffffffffffffffffffffffffff." + zilAddress);
            data = await response.json();
            return data;
        case "calculator": //calculator
            response = await fetch("https://calculator.ezil.me/api/ezil_calculator?hashrate=" + zilAddress + "&scale=1");
            data = await response.json();
            return data.etc;
        case "payouts":
            response = await fetch("https://billing.ezil.me/v2/accounts/0xffffffffffffffffffffffffffffffffffffffff." + zilAddress + "/payouts?page=1&per_page=10&coin=zil");
            data = await response.json();
            return data.data;
            
        default:
            return null;
    }
}